import { 
  User, InsertUser, 
  Product, InsertProduct,
  CartItem, InsertCartItem, 
  Order, InsertOrder, 
  OrderItem, InsertOrderItem, 
  Appointment, InsertAppointment,
  ContactSubmission, InsertContactSubmission
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

// Modify the interface with CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Product methods
  getProduct(id: number): Promise<Product | undefined>;
  getProducts(options?: {
    category?: string;
    subCategory?: string;
    type?: string;
    search?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    limit?: number;
    offset?: number;
  }): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Cart methods
  getCartItems(userId: number): Promise<(CartItem & { product: Product })[]>;
  getCartItem(id: number): Promise<CartItem | undefined>;
  getCartItemByUserAndProduct(userId: number, productId: number): Promise<CartItem | undefined>;
  createCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, cartItem: Partial<CartItem>): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;
  clearCart(userId: number): Promise<boolean>;
  
  // Order methods
  getOrder(id: number): Promise<(Order & { items: (OrderItem & { product: Product })[] }) | undefined>;
  getOrders(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<Order>): Promise<Order | undefined>;
  
  // Order Item methods
  getOrderItems(orderId: number): Promise<(OrderItem & { product: Product })[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // Appointment methods
  getAppointment(id: number): Promise<Appointment | undefined>;
  getAppointments(userId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<Appointment>): Promise<Appointment | undefined>;
  
  // Contact Submission methods
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  
  // Session Store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  public users: Map<number, User>; // Changed to public for admin access
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private appointments: Map<number, Appointment>;
  private contactSubmissions: Map<number, ContactSubmission>;
  sessionStore: session.SessionStore;
  
  // IDs for auto-increment
  private userId: number;
  private productId: number;
  private cartItemId: number;
  private orderId: number;
  private orderItemId: number;
  private appointmentId: number;
  private contactSubmissionId: number;
  
  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.appointments = new Map();
    this.contactSubmissions = new Map();
    
    this.userId = 1;
    this.productId = 1;
    this.cartItemId = 1;
    this.orderId = 1;
    this.orderItemId = 1;
    this.appointmentId = 1;
    this.contactSubmissionId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Initialize with admin user and products
    this.seedAdminUser();
    this.seedProducts();
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const isAdmin = insertUser.isAdmin ?? false;
    const phone = insertUser.phone ?? null;
    const address = insertUser.address ?? null;
    
    const user: User = { 
      ...insertUser, 
      id,
      isAdmin,
      phone,
      address,
      createdAt: now 
    };
    
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Product methods
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProducts(options: {
    category?: string;
    subCategory?: string;
    type?: string;
    search?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    limit?: number;
    offset?: number;
  } = {}): Promise<Product[]> {
    let products = Array.from(this.products.values());
    
    // Filter by category
    if (options.category) {
      products = products.filter(product => 
        product.category.toLowerCase() === options.category!.toLowerCase()
      );
    }
    
    // Filter by subCategory
    if (options.subCategory) {
      products = products.filter(product => 
        product.subCategory.toLowerCase() === options.subCategory!.toLowerCase()
      );
    }
    
    // Filter by type
    if (options.type) {
      products = products.filter(product => 
        product.type.toLowerCase() === options.type!.toLowerCase()
      );
    }
    
    // Search by name or description
    if (options.search) {
      const searchLower = options.search.toLowerCase();
      products = products.filter(product => 
        product.name.toLowerCase().includes(searchLower) || 
        product.description.toLowerCase().includes(searchLower)
      );
    }
    
    // Sort
    if (options.sortBy) {
      const sortOrder = options.sortOrder === 'desc' ? -1 : 1;
      products.sort((a, b) => {
        const fieldA = a[options.sortBy as keyof Product];
        const fieldB = b[options.sortBy as keyof Product];
        
        if (typeof fieldA === 'string' && typeof fieldB === 'string') {
          return sortOrder * fieldA.localeCompare(fieldB);
        } else if (typeof fieldA === 'number' && typeof fieldB === 'number') {
          return sortOrder * (fieldA - fieldB);
        } else if (fieldA instanceof Date && fieldB instanceof Date) {
          return sortOrder * (fieldA.getTime() - fieldB.getTime());
        }
        return 0;
      });
    }
    
    // Pagination
    if (options.offset !== undefined && options.limit !== undefined) {
      products = products.slice(options.offset, options.offset + options.limit);
    } else if (options.limit !== undefined) {
      products = products.slice(0, options.limit);
    }
    
    return products;
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const now = new Date();
    
    const discountPrice = insertProduct.discountPrice ?? null;
    const tags = insertProduct.tags ?? null;
    const rating = insertProduct.rating ?? null;
    const isNew = insertProduct.isNew ?? null;
    const isBestseller = insertProduct.isBestseller ?? null;
    const inStock = insertProduct.inStock ?? true;
    
    const product: Product = { 
      ...insertProduct, 
      id, 
      discountPrice,
      tags,
      rating,
      isNew,
      isBestseller,
      inStock,
      createdAt: now 
    };
    
    this.products.set(id, product);
    return product;
  }
  
  async updateProduct(id: number, productData: Partial<Product>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { ...product, ...productData };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }
  
  // Cart methods
  async getCartItems(userId: number): Promise<(CartItem & { product: Product })[]> {
    const cartItems = Array.from(this.cartItems.values())
      .filter(item => item.userId === userId);
    
    return cartItems.map(item => {
      const product = this.products.get(item.productId);
      if (!product) throw new Error(`Product not found for cart item: ${item.id}`);
      return { ...item, product };
    });
  }
  
  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }
  
  async getCartItemByUserAndProduct(userId: number, productId: number): Promise<CartItem | undefined> {
    return Array.from(this.cartItems.values()).find(
      item => item.userId === userId && item.productId === productId
    );
  }
  
  async createCartItem(insertCartItem: InsertCartItem): Promise<CartItem> {
    const id = this.cartItemId++;
    const now = new Date();
    const cartItem: CartItem = { ...insertCartItem, id, createdAt: now };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }
  
  async updateCartItem(id: number, cartItemData: Partial<CartItem>): Promise<CartItem | undefined> {
    const cartItem = this.cartItems.get(id);
    if (!cartItem) return undefined;
    
    const updatedCartItem = { ...cartItem, ...cartItemData };
    this.cartItems.set(id, updatedCartItem);
    return updatedCartItem;
  }
  
  async deleteCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }
  
  async clearCart(userId: number): Promise<boolean> {
    const cartItemsToDelete = Array.from(this.cartItems.values())
      .filter(item => item.userId === userId);
    
    cartItemsToDelete.forEach(item => {
      this.cartItems.delete(item.id);
    });
    
    return true;
  }
  
  // Order methods
  async getOrder(id: number): Promise<(Order & { items: (OrderItem & { product: Product })[] }) | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const items = await this.getOrderItems(id);
    return { ...order, items };
  }
  
  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderId++;
    const now = new Date();
    const order: Order = { ...insertOrder, id, createdAt: now };
    this.orders.set(id, order);
    return order;
  }
  
  async updateOrder(id: number, orderData: Partial<Order>): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, ...orderData };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }
  
  // Order Item methods
  async getOrderItems(orderId: number): Promise<(OrderItem & { product: Product })[]> {
    const orderItems = Array.from(this.orderItems.values())
      .filter(item => item.orderId === orderId);
    
    return orderItems.map(item => {
      const product = this.products.get(item.productId);
      if (!product) throw new Error(`Product not found for order item: ${item.id}`);
      return { ...item, product };
    });
  }
  
  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemId++;
    const now = new Date();
    const orderItem: OrderItem = { ...insertOrderItem, id, createdAt: now };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }
  
  // Appointment methods
  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }
  
  async getAppointments(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values())
      .filter(appointment => appointment.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentId++;
    const now = new Date();
    const appointment: Appointment = { ...insertAppointment, id, createdAt: now };
    this.appointments.set(id, appointment);
    return appointment;
  }
  
  async updateAppointment(id: number, appointmentData: Partial<Appointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;
    
    const updatedAppointment = { ...appointment, ...appointmentData };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }
  
  // Contact Submission methods
  async createContactSubmission(insertSubmission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = this.contactSubmissionId++;
    const now = new Date();
    const submission: ContactSubmission = { ...insertSubmission, id, createdAt: now };
    this.contactSubmissions.set(id, submission);
    return submission;
  }
  
  // Seed data for products
  private seedProducts() {
    // Eyeglasses - Prescribed
    this.createProduct({
      name: "Modern Round Frame",
      description: "Lightweight titanium frame with round lenses, perfect for everyday wear.",
      price: 129.00,
      discountPrice: 99.00,
      imageUrl: "https://images.unsplash.com/photo-1574258495973-f010dfbb5371?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: "eyeglasses",
      subCategory: "prescribed",
      type: "single vision",
      tags: ["titanium", "round", "lightweight"],
      inStock: true,
      rating: 4.5,
      isNew: true,
      isBestseller: false
    });
    
    this.createProduct({
      name: "Classic Rectangle Frame",
      description: "Durable acetate frame with rectangle lenses, suitable for all face shapes.",
      price: 149.00,
      discountPrice: null,
      imageUrl: "https://images.unsplash.com/photo-1591076482161-42ce6da69f67?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: "eyeglasses",
      subCategory: "prescribed",
      type: "bifocal",
      tags: ["acetate", "rectangle", "durable"],
      inStock: true,
      rating: 4.2,
      isNew: false,
      isBestseller: true
    });
    
    // Eyeglasses - Non-Prescribed
    this.createProduct({
      name: "Blue Light Blocker",
      description: "Stylish frames with blue light filtering technology to reduce eye strain.",
      price: 79.00,
      discountPrice: null,
      imageUrl: "https://images.unsplash.com/photo-1573621620742-fb7503c541fe?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: "eyeglasses",
      subCategory: "non-prescribed",
      type: "blue light filtering",
      tags: ["blue light", "computer", "anti-fatigue"],
      inStock: true,
      rating: 4.7,
      isNew: true,
      isBestseller: false
    });
    
    // Sunglasses - Prescribed
    this.createProduct({
      name: "Polarized Prescription Aviator",
      description: "Classic aviator style with prescription polarized lenses for clear vision and UV protection.",
      price: 189.00,
      discountPrice: 159.00,
      imageUrl: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: "sunglasses",
      subCategory: "prescribed",
      type: "polarized prescription",
      tags: ["aviator", "polarized", "UV protection"],
      inStock: true,
      rating: 4.8,
      isNew: false,
      isBestseller: true
    });
    
    // Sunglasses - Non-Prescribed
    this.createProduct({
      name: "Urban Cat Eye",
      description: "Stylish cat eye sunglasses with gradient lenses, perfect for summer fashion.",
      price: 89.00,
      discountPrice: null,
      imageUrl: "https://images.unsplash.com/photo-1546180572-28e937c8128b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: "sunglasses",
      subCategory: "non-prescribed",
      type: "fashion",
      tags: ["cat eye", "gradient", "fashion"],
      inStock: true,
      rating: 4.6,
      isNew: false,
      isBestseller: true
    });
    
    // Lenses - Prescribed
    this.createProduct({
      name: "Monthly Prescription Contacts",
      description: "Comfortable monthly replacement contact lenses for all-day wear.",
      price: 45.00,
      discountPrice: null,
      imageUrl: "https://images.unsplash.com/photo-1607858426400-bf8eba6345f9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: "lenses",
      subCategory: "prescribed",
      type: "corrective",
      tags: ["monthly", "comfortable", "hydrating"],
      inStock: true,
      rating: 4.4,
      isNew: false,
      isBestseller: false
    });
    
    // Lenses - Non-Prescribed
    this.createProduct({
      name: "Colored Cosmetic Lenses",
      description: "Vibrant colored contact lenses to transform your look for any occasion.",
      price: 35.00,
      discountPrice: 29.99,
      imageUrl: "https://images.unsplash.com/photo-1587654780291-39c9404d746b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: "lenses",
      subCategory: "non-prescribed",
      type: "cosmetic",
      tags: ["colored", "cosmetic", "fashion"],
      inStock: true,
      rating: 4.3,
      isNew: true,
      isBestseller: false
    });
  }
}

export const storage = new MemStorage();
