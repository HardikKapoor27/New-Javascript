import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/ui/theme-toggle";
import { CartProvider } from "@/hooks/use-cart";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

import HomePage from "@/pages/home-page";
import EyeglassesPage from "@/pages/eyeglasses-page";
import SunglassesPage from "@/pages/sunglasses-page";
import LensesPage from "@/pages/lenses-page";
import AppointmentPage from "@/pages/appointment-page";
import ContactPage from "@/pages/contact-page";
import AuthPage from "@/pages/auth-page";
import CartPage from "@/pages/cart-page";
import AccountPage from "@/pages/account-page";
import AdminDashboard from "@/pages/admin-dashboard";
import ProductDetailPage from "@/pages/product-detail-page";
import NotFound from "@/pages/not-found";
import SiteHeader from "@/components/layout/site-header";
import Footer from "@/components/layout/footer";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/eyeglasses" component={EyeglassesPage} />
          <Route path="/sunglasses" component={SunglassesPage} />
          <Route path="/lenses" component={LensesPage} />
          <Route path="/appointment" component={AppointmentPage} />
          <Route path="/contact" component={ContactPage} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/product/:id" component={ProductDetailPage} />
          <ProtectedRoute path="/cart" component={CartPage} />
          <ProtectedRoute path="/account" component={AccountPage} />
          <ProtectedRoute path="/admin" component={AdminDashboard} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <CartProvider>
            <Router />
            <Toaster />
          </CartProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
