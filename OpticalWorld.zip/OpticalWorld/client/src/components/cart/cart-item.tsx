import { useState } from "react";
import { Link } from "wouter";
import { Product, CartItem } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash, Minus, Plus } from "lucide-react";
import { useCart } from "@/hooks/use-cart";

interface CartItemProps {
  item: CartItem & { product: Product };
}

export default function CartItemComponent({ item }: CartItemProps) {
  const { updateCartMutation, removeFromCartMutation } = useCart();
  const [quantity, setQuantity] = useState(item.quantity);
  
  const productPrice = item.product.discountPrice || item.product.price;
  const itemTotal = productPrice * item.quantity;
  
  const handleQuantityChange = (value: number) => {
    if (value < 1) return;
    
    setQuantity(value);
    
    // Debounce the API call
    const timeoutId = setTimeout(() => {
      updateCartMutation.mutate({ id: item.id, quantity: value });
    }, 500);
    
    return () => clearTimeout(timeoutId);
  };
  
  const handleRemove = () => {
    removeFromCartMutation.mutate(item.id);
  };
  
  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center py-6 border-b">
      <div className="flex items-center mb-4 sm:mb-0 sm:mr-6">
        <div className="relative w-20 h-20 mr-4">
          <img 
            src={item.product.imageUrl} 
            alt={item.product.name} 
            className="w-full h-full object-cover rounded"
          />
        </div>
        <div className="flex-1 min-w-0">
          <Link href={`/product/${item.product.id}`}>
            <h3 className="font-medium hover:text-primary truncate">{item.product.name}</h3>
          </Link>
          <p className="text-sm text-muted-foreground truncate">
            {item.product.category.charAt(0).toUpperCase() + item.product.category.slice(1)} - {item.product.type}
          </p>
          <div className="mt-1">
            {item.product.discountPrice ? (
              <div className="flex items-center">
                <span className="font-semibold">${item.product.discountPrice.toFixed(2)}</span>
                <span className="text-sm text-muted-foreground line-through ml-2">
                  ${item.product.price.toFixed(2)}
                </span>
              </div>
            ) : (
              <span className="font-semibold">${item.product.price.toFixed(2)}</span>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-between w-full sm:w-auto sm:ml-auto">
        <div className="flex items-center">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 rounded-r-none"
            onClick={() => handleQuantityChange(quantity - 1)}
            disabled={quantity <= 1 || updateCartMutation.isPending}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <Input
            type="number"
            value={quantity}
            onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
            min={1}
            className="h-8 w-14 rounded-none text-center [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
          />
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 rounded-l-none"
            onClick={() => handleQuantityChange(quantity + 1)}
            disabled={updateCartMutation.isPending}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex items-center ml-6 sm:ml-8">
          <span className="font-semibold mr-4 sm:mr-8 min-w-[60px] text-right">
            ${itemTotal.toFixed(2)}
          </span>
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-destructive"
            onClick={handleRemove}
            disabled={removeFromCartMutation.isPending}
          >
            <Trash className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
