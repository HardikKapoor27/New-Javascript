import { useState } from "react";
import { useLocation } from "wouter";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";

interface ProductFilterProps {
  category: string;
  currentFilters: {
    subCategory?: string;
    type?: string;
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
  };
  onFilterChange: (filters: any) => void;
}

export default function ProductFilter({ 
  category, 
  currentFilters,
  onFilterChange 
}: ProductFilterProps) {
  const [, setLocation] = useLocation();
  const [subCategory, setSubCategory] = useState<string | undefined>(currentFilters.subCategory);
  const [type, setType] = useState<string | undefined>(currentFilters.type);
  const [priceRange, setPriceRange] = useState<[number, number]>([
    currentFilters.minPrice || 0, 
    currentFilters.maxPrice || 500
  ]);
  const [sort, setSort] = useState<string>(currentFilters.sort || "featured");

  const getSubCategories = () => {
    return [
      { id: "prescribed", label: "Prescribed" },
      { id: "non-prescribed", label: "Non-Prescribed" }
    ];
  };

  const getTypes = () => {
    if (category === "eyeglasses") {
      if (subCategory === "prescribed") {
        return [
          { id: "single vision", label: "Single Vision" },
          { id: "bifocal", label: "Bifocal Lenses" },
          { id: "progressive", label: "Progressive Lenses" },
          { id: "reading", label: "Reading Glasses" },
          { id: "high-index", label: "High-index Lenses" }
        ];
      } else if (subCategory === "non-prescribed") {
        return [
          { id: "fashion", label: "Fashion Eyeglasses" },
          { id: "blue light filtering", label: "Blue Light Filtering" },
          { id: "gaming", label: "Gaming Glasses" },
          { id: "anti-fatigue", label: "Anti-fatigue Glasses" }
        ];
      }
    } else if (category === "sunglasses") {
      if (subCategory === "prescribed") {
        return [
          { id: "polarized prescription", label: "Polarized Prescription" },
          { id: "photochromic", label: "Photochromic Lenses" }
        ];
      } else if (subCategory === "non-prescribed") {
        return [
          { id: "standard", label: "Standard Sunglasses" },
          { id: "polarized", label: "Polarized Sunglasses" },
          { id: "sports", label: "Sports Sunglasses" },
          { id: "fashion", label: "Fashion Sunglasses" }
        ];
      }
    } else if (category === "lenses") {
      if (subCategory === "prescribed") {
        return [
          { id: "corrective", label: "Corrective Contact Lenses" },
          { id: "multifocal", label: "Multifocal Contact Lenses" },
          { id: "toric", label: "Toric Lenses" }
        ];
      } else if (subCategory === "non-prescribed") {
        return [
          { id: "cosmetic", label: "Cosmetic Contact Lenses" },
          { id: "blue light blocking", label: "Blue Light Blocking" },
          { id: "uv protective", label: "UV Protective Lenses" }
        ];
      }
    }
    return [];
  };

  const handleSubCategoryChange = (value: string) => {
    const newSubCategory = subCategory === value ? undefined : value;
    setSubCategory(newSubCategory);
    setType(undefined); // Reset type when subcategory changes
    applyFilters({ subCategory: newSubCategory, type: undefined });
  };

  const handleTypeChange = (value: string) => {
    const newType = type === value ? undefined : value;
    setType(newType);
    applyFilters({ type: newType });
  };

  const handlePriceChange = (value: [number, number]) => {
    setPriceRange(value);
  };

  const handleSortChange = (value: string) => {
    setSort(value);
    applyFilters({ sort: value });
  };

  const applyFilters = (newFilters: any) => {
    const filters = {
      ...currentFilters,
      ...newFilters
    };
    
    // Remove undefined values
    Object.keys(filters).forEach(key => 
      filters[key] === undefined && delete filters[key]
    );

    onFilterChange(filters);
    
    // Update URL
    const searchParams = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        searchParams.set(key, value as string);
      }
    });
    
    setLocation(`/${category}?${searchParams.toString()}`);
  };

  const handleApplyPriceFilter = () => {
    applyFilters({ 
      minPrice: priceRange[0],
      maxPrice: priceRange[1]
    });
  };

  const handleClearFilters = () => {
    setSubCategory(undefined);
    setType(undefined);
    setPriceRange([0, 500]);
    setSort("featured");
    
    // Clear URL params but keep the category
    setLocation(`/${category}`);
    onFilterChange({});
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Filters</h2>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={handleClearFilters}
          className="text-primary hover:text-primary/80"
        >
          Clear All
        </Button>
      </div>

      <Accordion type="multiple" defaultValue={["subcategory", "type", "price", "sort"]}>
        <AccordionItem value="subcategory">
          <AccordionTrigger>Category</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {getSubCategories().map((item) => (
                <div key={item.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`subcategory-${item.id}`} 
                    checked={subCategory === item.id}
                    onCheckedChange={() => handleSubCategoryChange(item.id)}
                  />
                  <Label 
                    htmlFor={`subcategory-${item.id}`}
                    className="cursor-pointer"
                  >
                    {item.label}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {subCategory && (
          <AccordionItem value="type">
            <AccordionTrigger>Type</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2">
                {getTypes().map((item) => (
                  <div key={item.id} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`type-${item.id}`} 
                      checked={type === item.id}
                      onCheckedChange={() => handleTypeChange(item.id)}
                    />
                    <Label 
                      htmlFor={`type-${item.id}`}
                      className="cursor-pointer"
                    >
                      {item.label}
                    </Label>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        )}

        <AccordionItem value="price">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <Slider
                defaultValue={priceRange}
                max={500}
                step={10}
                value={priceRange}
                onValueChange={(value) => handlePriceChange(value as [number, number])}
                className="my-6"
              />
              <div className="flex justify-between">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleApplyPriceFilter}
                className="w-full mt-2"
              >
                Apply
              </Button>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="sort">
          <AccordionTrigger>Sort By</AccordionTrigger>
          <AccordionContent>
            <RadioGroup 
              value={sort} 
              onValueChange={handleSortChange}
              className="space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="featured" id="sort-featured" />
                <Label htmlFor="sort-featured">Featured</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="price-low" id="sort-price-low" />
                <Label htmlFor="sort-price-low">Price: Low to High</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="price-high" id="sort-price-high" />
                <Label htmlFor="sort-price-high">Price: High to Low</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="newest" id="sort-newest" />
                <Label htmlFor="sort-newest">Newest First</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="rating" id="sort-rating" />
                <Label htmlFor="sort-rating">Highest Rated</Label>
              </div>
            </RadioGroup>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
