import { useState } from "react";
import { Link } from "wouter";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, ShoppingCart, Check } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { user } = useAuth();
  const { addToCartMutation } = useCart();
  const { toast } = useToast();
  const [isAddedToCart, setIsAddedToCart] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!user) {
      toast({
        title: "Please login",
        description: "You need to be logged in to add items to your cart.",
        variant: "destructive",
      });
      return;
    }
    
    addToCartMutation.mutate(
      { productId: product.id, quantity: 1 },
      {
        onSuccess: () => {
          setIsAddedToCart(true);
          setTimeout(() => setIsAddedToCart(false), 1500);
        }
      }
    );
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={`star-${i}`} className="fas fa-star text-yellow-400 text-xs"></i>);
    }

    if (hasHalfStar) {
      stars.push(<i key="half-star" className="fas fa-star-half-alt text-yellow-400 text-xs"></i>);
    }

    const remaining = 5 - stars.length;
    for (let i = 0; i < remaining; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star text-yellow-400 text-xs"></i>);
    }

    return stars;
  };

  return (
    <Link href={`/product/${product.id}`}>
      <div className="product-card bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer">
        <div className="relative">
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-64 object-cover"
          />
          {product.isNew && (
            <Badge className="absolute top-2 left-2 bg-primary hover:bg-primary">
              New Arrival
            </Badge>
          )}
          {product.isBestseller && (
            <Badge className="absolute top-2 left-2" variant="secondary">
              Bestseller
            </Badge>
          )}
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute top-2 right-2 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:text-primary"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              toast({
                title: "Added to wishlist",
                description: `${product.name} has been added to your wishlist.`,
              });
            }}
          >
            <Heart className="h-5 w-5" />
            <span className="sr-only">Add to wishlist</span>
          </Button>
        </div>
        <div className="p-4">
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-semibold truncate">{product.name}</h3>
            <div className="flex">
              {renderStars(product.rating)}
            </div>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2 truncate">{product.description}</p>
          <div className="flex justify-between items-center">
            <div>
              {product.discountPrice ? (
                <>
                  <span className="font-bold">${product.discountPrice.toFixed(2)}</span>
                  <span className="text-sm text-gray-500 line-through ml-2">${product.price.toFixed(2)}</span>
                </>
              ) : (
                <span className="font-bold">${product.price.toFixed(2)}</span>
              )}
            </div>
            <Button 
              variant="default" 
              size="icon" 
              className="rounded-full"
              onClick={handleAddToCart}
              disabled={addToCartMutation.isPending || isAddedToCart}
            >
              {isAddedToCart ? (
                <Check className="h-5 w-5" />
              ) : addToCartMutation.isPending ? (
                <span className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <ShoppingCart className="h-5 w-5" />
              )}
              <span className="sr-only">Add to cart</span>
            </Button>
          </div>
        </div>
      </div>
    </Link>
  );
}
