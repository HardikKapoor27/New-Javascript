import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative">
      <div className="relative h-[500px] md:h-[600px] w-full">
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent z-10"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: "url('https://images.unsplash.com/photo-1574258495973-f010dfbb5371?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80')"
          }}
        ></div>
        <div className="absolute inset-0 flex items-center z-20">
          <div className="container mx-auto px-6">
            <div className="max-w-lg">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 font-heading">
                See the World Through Perfect Vision
              </h1>
              <p className="text-white text-lg mb-8">
                Discover the latest eyewear trends and vision solutions at Ainak. Quality frames, lenses, and expert service.
              </p>
              <Button asChild size="lg" className="group">
                <Link href="/eyeglasses">
                  Explore Now
                  <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
