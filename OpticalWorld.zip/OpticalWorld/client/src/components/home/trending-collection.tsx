import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronRight } from "lucide-react";
import ProductCard from "@/components/products/product-card";
import { Product } from "@shared/schema";

export default function TrendingCollection() {
  const [activeTab, setActiveTab] = useState("all");

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products", { limit: 8 }],
  });

  const filteredProducts = products.filter(product => {
    if (activeTab === "all") return true;
    return product.category === activeTab;
  });

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 font-heading">New & Trending Collections</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Discover our latest arrivals and bestselling eyewear to elevate your style and vision.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="mb-10 flex justify-center">
          <Tabs
            defaultValue="all"
            value={activeTab}
            onValueChange={setActiveTab}
            className="w-full max-w-md"
          >
            <TabsList className="grid grid-cols-4 w-full">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="eyeglasses">Eyeglasses</TabsTrigger>
              <TabsTrigger value="sunglasses">Sunglasses</TabsTrigger>
              <TabsTrigger value="lenses">Lenses</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {isLoading ? (
            // Loading skeleton
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm animate-pulse">
                <div className="h-64 bg-gray-200 dark:bg-gray-700"></div>
                <div className="p-4">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-4"></div>
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                </div>
              </div>
            ))
          ) : (
            filteredProducts.slice(0, 4).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))
          )}
        </div>

        <div className="text-center mt-12">
          <Button asChild size="lg" className="group">
            <Link href="/eyeglasses">
              View All Products
              <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
