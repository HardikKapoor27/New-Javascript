import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight } from "lucide-react";

export default function AppointmentCTA() {
  return (
    <section className="py-16 bg-primary">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6 text-white font-heading">Your Eyes Deserve the Best Care</h2>
        <p className="text-white text-lg mb-8 max-w-3xl mx-auto">
          Regular eye check-ups are essential for maintaining good vision and detecting potential issues early. Our expert optometrists use advanced technology to ensure your eyes stay healthy.
        </p>
        <div className="flex flex-wrap justify-center gap-8 mb-12">
          <Card className="max-w-xs">
            <CardContent className="p-6 flex flex-col items-center">
              <div className="text-primary text-3xl mb-4">
                <i className="fas fa-calendar-check"></i>
              </div>
              <h3 className="font-semibold text-xl mb-2">Comprehensive Eye Exam</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm text-center">
                Complete evaluation of your eye health and vision with our skilled optometrists.
              </p>
            </CardContent>
          </Card>
          <Card className="max-w-xs">
            <CardContent className="p-6 flex flex-col items-center">
              <div className="text-primary text-3xl mb-4">
                <i className="fas fa-eye"></i>
              </div>
              <h3 className="font-semibold text-xl mb-2">Prescription Update</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm text-center">
                Get your prescription refreshed to ensure optimal vision with your eyewear.
              </p>
            </CardContent>
          </Card>
          <Card className="max-w-xs">
            <CardContent className="p-6 flex flex-col items-center">
              <div className="text-primary text-3xl mb-4">
                <i className="fas fa-glasses"></i>
              </div>
              <h3 className="font-semibold text-xl mb-2">Frame Fitting</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm text-center">
                Professional assistance in selecting and fitting the perfect frames for your face.
              </p>
            </CardContent>
          </Card>
        </div>
        <Button asChild variant="secondary" size="lg" className="group">
          <Link href="/appointment">
            Book Your Appointment
            <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </Button>
      </div>
    </section>
  );
}
