import { Card, CardContent } from "@/components/ui/card";

export default function TestimonialSection() {
  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Loyal Customer",
      avatar: "https://randomuser.me/api/portraits/women/32.jpg",
      quote: "The selection at Ainak is amazing! I found the perfect pair of glasses that not only corrected my vision but also matched my style. The staff was knowledgeable and patient.",
      rating: 5
    },
    {
      id: 2,
      name: "James Wilson",
      role: "New Customer",
      avatar: "https://randomuser.me/api/portraits/men/41.jpg",
      quote: "I was hesitant about ordering glasses online, but Ainak made it so easy. The virtual try-on feature helped me choose, and the glasses arrived perfectly fitted. Very impressed!",
      rating: 5
    },
    {
      id: 3,
      name: "Priya Sharma",
      role: "Regular Customer",
      avatar: "https://randomuser.me/api/portraits/women/68.jpg",
      quote: "The eye exam at Ainak was thorough and the optometrist took time to explain everything. I've been wearing their contact lenses for 6 months now and they're the most comfortable I've ever had.",
      rating: 4.5
    }
  ];

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={`star-${i}`} className="fas fa-star text-yellow-400"></i>);
    }

    if (hasHalfStar) {
      stars.push(<i key="half-star" className="fas fa-star-half-alt text-yellow-400"></i>);
    }

    const remaining = 5 - stars.length;
    for (let i = 0; i < remaining; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star text-yellow-400"></i>);
    }

    return stars;
  };

  return (
    <section className="py-16 bg-white dark:bg-gray-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 font-heading">What Our Customers Say</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Don't just take our word for it – hear from our satisfied customers about their Ainak experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="bg-gray-50 dark:bg-gray-900">
              <CardContent className="p-6">
                <div className="flex space-x-1 mb-4">
                  {renderStars(testimonial.rating)}
                </div>
                <p className="text-gray-700 dark:text-gray-300 italic mb-6">
                  "{testimonial.quote}"
                </p>
                <div className="flex items-center">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.name} 
                    className="w-12 h-12 rounded-full mr-4" 
                  />
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
