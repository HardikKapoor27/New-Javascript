import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, ChevronRight } from "lucide-react";

export default function OffersSection() {
  return (
    <section className="py-16 bg-white dark:bg-gray-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 font-heading">Special Offers & Discounts</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Explore our limited-time deals and save on premium eyewear and vision care services.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Offer Card 1 */}
          <Card>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1591076482161-42ce6da69f67?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80" 
                alt="Summer Sale" 
                className="w-full h-48 object-cover rounded-t-lg"
              />
              <Badge className="absolute top-2 right-2 bg-primary hover:bg-primary">
                30% OFF
              </Badge>
            </div>
            <CardContent className="p-6">
              <h3 className="font-bold text-xl mb-2">Summer Eyewear Sale</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Get 30% off on all sunglasses. Perfect time to upgrade your summer style.
              </p>
            </CardContent>
            <CardFooter className="px-6 pb-6 pt-0 flex items-center justify-between">
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <Clock className="mr-1 h-4 w-4" />
                <span>Ends in 15 days</span>
              </div>
              <Link href="/sunglasses" className="text-primary font-medium hover:underline">
                Shop Now
              </Link>
            </CardFooter>
          </Card>

          {/* Offer Card 2 */}
          <Card>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1577803645773-f96470509666?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80" 
                alt="BOGO Offer" 
                className="w-full h-48 object-cover rounded-t-lg"
              />
              <Badge className="absolute top-2 right-2" variant="secondary">
                BOGO
              </Badge>
            </div>
            <CardContent className="p-6">
              <h3 className="font-bold text-xl mb-2">Buy One Get One Free</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Purchase any prescription eyeglasses and get a second pair completely free.
              </p>
            </CardContent>
            <CardFooter className="px-6 pb-6 pt-0 flex items-center justify-between">
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <Clock className="mr-1 h-4 w-4" />
                <span>Limited time offer</span>
              </div>
              <Link href="/eyeglasses" className="text-primary font-medium hover:underline">
                Shop Now
              </Link>
            </CardFooter>
          </Card>

          {/* Offer Card 3 */}
          <Card>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1587654780291-39c9404d746b?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80" 
                alt="Contact Lens Bundle" 
                className="w-full h-48 object-cover rounded-t-lg"
              />
              <Badge className="absolute top-2 right-2 bg-primary hover:bg-primary">
                SAVE 25%
              </Badge>
            </div>
            <CardContent className="p-6">
              <h3 className="font-bold text-xl mb-2">Contact Lens Bundle</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Save 25% when you purchase a 6-month supply of contact lenses plus solution.
              </p>
            </CardContent>
            <CardFooter className="px-6 pb-6 pt-0 flex items-center justify-between">
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <Clock className="mr-1 h-4 w-4" />
                <span>Ends in 7 days</span>
              </div>
              <Link href="/lenses" className="text-primary font-medium hover:underline">
                Shop Now
              </Link>
            </CardFooter>
          </Card>
        </div>

        <div className="text-center mt-12">
          <Button asChild variant="outline" className="group">
            <Link href="/eyeglasses">
              View All Offers
              <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
