import { Card, CardContent } from "@/components/ui/card";

export default function AboutSection() {
  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <img 
              src="https://images.unsplash.com/photo-1556015048-4d3aa10df74c?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80" 
              alt="Our optical store" 
              className="rounded-lg shadow-lg"
            />
          </div>
          <div className="md:w-1/2 md:pl-12">
            <h2 className="text-3xl font-bold mb-6 font-heading">Our Optical Store</h2>
            <p className="text-gray-700 dark:text-gray-300 mb-6">
              At Ainak, we believe everyone deserves clear vision and stylish eyewear that reflects their personality. With over 15 years of experience, our optical experts provide personalized service to help you find the perfect eyewear solution.
            </p>
            <p className="text-gray-700 dark:text-gray-300 mb-8">
              We offer a wide range of premium eyeglasses, sunglasses, and contact lenses from leading brands, along with comprehensive eye examinations using state-of-the-art equipment.
            </p>
            <div className="grid grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-4 flex items-start">
                  <div className="text-primary mr-4 text-2xl">
                    <i className="fas fa-glasses"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Premium Brands</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Curated selection of high-quality eyewear</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 flex items-start">
                  <div className="text-primary mr-4 text-2xl">
                    <i className="fas fa-user-md"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Expert Advice</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Professional optometrists and stylists</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 flex items-start">
                  <div className="text-primary mr-4 text-2xl">
                    <i className="fas fa-sync-alt"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Easy Returns</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">30-day hassle-free return policy</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 flex items-start">
                  <div className="text-primary mr-4 text-2xl">
                    <i className="fas fa-truck"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Fast Delivery</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Quick shipping nationwide</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
