import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { 
  Menu, 
  Search, 
  User, 
  ShoppingCart, 
  ChevronDown,
  LogIn,
  UserPlus,
  Package,
  Settings,
  LogOut
} from "lucide-react";

export default function SiteHeader() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { totalItems } = useCart();
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const eyeglassesSubcategories = {
    men: [
      { name: "Men's Single Vision", href: "/eyeglasses?subCategory=prescribed&type=single+vision&gender=men" },
      { name: "Men's Bifocal Lenses", href: "/eyeglasses?subCategory=prescribed&type=bifocal&gender=men" },
      { name: "Men's Progressive Lenses", href: "/eyeglasses?subCategory=prescribed&type=progressive&gender=men" },
      { name: "Men's Fashion Frames", href: "/eyeglasses?subCategory=non-prescribed&type=fashion&gender=men" },
      { name: "Men's Blue Light Filtering", href: "/eyeglasses?subCategory=non-prescribed&type=blue+light+filtering&gender=men" },
    ],
    women: [
      { name: "Women's Single Vision", href: "/eyeglasses?subCategory=prescribed&type=single+vision&gender=women" },
      { name: "Women's Bifocal Lenses", href: "/eyeglasses?subCategory=prescribed&type=bifocal&gender=women" },
      { name: "Women's Progressive Lenses", href: "/eyeglasses?subCategory=prescribed&type=progressive&gender=women" },
      { name: "Women's Fashion Frames", href: "/eyeglasses?subCategory=non-prescribed&type=fashion&gender=women" },
      { name: "Women's Blue Light Filtering", href: "/eyeglasses?subCategory=non-prescribed&type=blue+light+filtering&gender=women" },
    ],
    kids: [
      { name: "Kids' Single Vision", href: "/eyeglasses?subCategory=prescribed&type=single+vision&gender=kids" },
      { name: "Kids' Fashion Frames", href: "/eyeglasses?subCategory=non-prescribed&type=fashion&gender=kids" },
      { name: "Kids' Blue Light Filtering", href: "/eyeglasses?subCategory=non-prescribed&type=blue+light+filtering&gender=kids" },
    ],
    other: [
      { name: "Reading Glasses", href: "/eyeglasses?subCategory=prescribed&type=reading" },
      { name: "High-index Lenses", href: "/eyeglasses?subCategory=prescribed&type=high-index" },
      { name: "Gaming Glasses", href: "/eyeglasses?subCategory=non-prescribed&type=gaming" },
      { name: "Anti-fatigue Glasses", href: "/eyeglasses?subCategory=non-prescribed&type=anti-fatigue" },
    ]
  };

  const sunglassesSubcategories = {
    men: [
      { name: "Men's Polarized Prescription", href: "/sunglasses?subCategory=prescribed&type=polarized+prescription&gender=men" },
      { name: "Men's Standard Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=standard&gender=men" },
      { name: "Men's Sports Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=sports&gender=men" },
      { name: "Men's Fashion Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=fashion&gender=men" },
    ],
    women: [
      { name: "Women's Polarized Prescription", href: "/sunglasses?subCategory=prescribed&type=polarized+prescription&gender=women" },
      { name: "Women's Standard Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=standard&gender=women" },
      { name: "Women's Fashion Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=fashion&gender=women" },
      { name: "Women's Oversized Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=oversized&gender=women" },
    ],
    kids: [
      { name: "Kids' Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=standard&gender=kids" },
      { name: "Kids' Sports Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=sports&gender=kids" },
    ],
    other: [
      { name: "Photochromic Lenses", href: "/sunglasses?subCategory=prescribed&type=photochromic" },
      { name: "Polarized Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=polarized" },
    ]
  };

  const lensesSubcategories = {
    men: [
      { name: "Men's Corrective Lenses", href: "/lenses?subCategory=prescribed&type=corrective&gender=men" },
      { name: "Men's Multifocal Lenses", href: "/lenses?subCategory=prescribed&type=multifocal&gender=men" },
      { name: "Men's Toric Lenses", href: "/lenses?subCategory=prescribed&type=toric&gender=men" },
    ],
    women: [
      { name: "Women's Corrective Lenses", href: "/lenses?subCategory=prescribed&type=corrective&gender=women" },
      { name: "Women's Multifocal Lenses", href: "/lenses?subCategory=prescribed&type=multifocal&gender=women" },
      { name: "Women's Toric Lenses", href: "/lenses?subCategory=prescribed&type=toric&gender=women" },
      { name: "Women's Cosmetic Lenses", href: "/lenses?subCategory=non-prescribed&type=cosmetic&gender=women" },
    ],
    kids: [
      { name: "Kids' Corrective Lenses", href: "/lenses?subCategory=prescribed&type=corrective&gender=kids" },
      { name: "Kids' Protective Lenses", href: "/lenses?subCategory=non-prescribed&type=uv+protective&gender=kids" },
    ],
    other: [
      { name: "Cosmetic Contact Lenses", href: "/lenses?subCategory=non-prescribed&type=cosmetic" },
      { name: "Blue Light Blocking", href: "/lenses?subCategory=non-prescribed&type=blue+light+blocking" },
      { name: "UV Protective Lenses", href: "/lenses?subCategory=non-prescribed&type=uv+protective" },
    ]
  };

  const isActive = (path: string) => {
    return location === path;
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="container mx-auto px-4 py-4 flex flex-wrap items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex flex-col">
          <span className="flex items-center text-2xl font-bold text-primary font-heading">
            <i className="fas fa-glasses mr-2"></i>
            Ainak
          </span>
          <span className="text-sm text-muted-foreground">The Optical Store</span>
        </Link>

        {/* Mobile Menu */}
        <div className="flex items-center lg:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="mr-2">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <div className="grid gap-4 py-4">
                <Link href="/" className="px-2 py-1 text-lg font-semibold">
                  Home
                </Link>
                <div className="px-2">
                  <div className="text-lg font-semibold mb-2">Eyeglasses</div>
                  <div className="grid grid-cols-1 gap-1">
                    <div className="font-medium ml-2 mb-1">Men</div>
                    {eyeglassesSubcategories.men.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Women</div>
                    {eyeglassesSubcategories.women.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Kids</div>
                    {eyeglassesSubcategories.kids.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Other Options</div>
                    {eyeglassesSubcategories.other.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>
                </div>
                <div className="px-2">
                  <div className="text-lg font-semibold mb-2">Sunglasses</div>
                  <div className="grid grid-cols-1 gap-1">
                    <div className="font-medium ml-2 mb-1">Men</div>
                    {sunglassesSubcategories.men.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Women</div>
                    {sunglassesSubcategories.women.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Kids</div>
                    {sunglassesSubcategories.kids.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Other Options</div>
                    {sunglassesSubcategories.other.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>
                </div>
                <div className="px-2">
                  <div className="text-lg font-semibold mb-2">Lenses</div>
                  <div className="grid grid-cols-1 gap-1">
                    <div className="font-medium ml-2 mb-1">Men</div>
                    {lensesSubcategories.men.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Women</div>
                    {lensesSubcategories.women.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Kids</div>
                    {lensesSubcategories.kids.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                    <div className="font-medium ml-2 mt-2 mb-1">Other Options</div>
                    {lensesSubcategories.other.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="ml-4 text-sm text-muted-foreground hover:text-primary"
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>
                </div>
                <Link href="/appointment" className="px-2 py-1 text-lg font-semibold">
                  Appointment
                </Link>
                <Link href="/contact" className="px-2 py-1 text-lg font-semibold">
                  Contact Us
                </Link>
              </div>
            </SheetContent>
          </Sheet>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="icon" onClick={() => setIsSearchOpen(!isSearchOpen)}>
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>
            <Link href={user ? "/account" : "/auth"}>
              <Button variant="outline" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">Account</span>
              </Button>
            </Link>
            <Link href="/cart">
              <Button variant="outline" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {totalItems > 9 ? '9+' : totalItems}
                  </span>
                )}
                <span className="sr-only">Cart</span>
              </Button>
            </Link>
          </div>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex lg:flex-1 lg:items-center lg:justify-center">
          <nav className="flex space-x-6">
            <Link 
              href="/" 
              className={`relative py-2 text-sm font-medium transition-colors ${isActive('/') ? 'text-primary' : 'hover:text-primary'}`}
            >
              Home
              {isActive('/') && (
                <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
              )}
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center py-2 text-sm font-medium transition-colors hover:text-primary">
                Eyeglasses <ChevronDown className="ml-1 h-4 w-4" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-64">
                <DropdownMenuLabel>Men</DropdownMenuLabel>
                {eyeglassesSubcategories.men.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Women</DropdownMenuLabel>
                {eyeglassesSubcategories.women.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Kids</DropdownMenuLabel>
                {eyeglassesSubcategories.kids.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Other Options</DropdownMenuLabel>
                {eyeglassesSubcategories.other.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/eyeglasses" className="font-medium text-primary">View All Eyeglasses</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center py-2 text-sm font-medium transition-colors hover:text-primary">
                Sunglasses <ChevronDown className="ml-1 h-4 w-4" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-64">
                <DropdownMenuLabel>Men</DropdownMenuLabel>
                {sunglassesSubcategories.men.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Women</DropdownMenuLabel>
                {sunglassesSubcategories.women.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Kids</DropdownMenuLabel>
                {sunglassesSubcategories.kids.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Other Options</DropdownMenuLabel>
                {sunglassesSubcategories.other.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/sunglasses" className="font-medium text-primary">View All Sunglasses</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center py-2 text-sm font-medium transition-colors hover:text-primary">
                Lenses <ChevronDown className="ml-1 h-4 w-4" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-64">
                <DropdownMenuLabel>Men</DropdownMenuLabel>
                {lensesSubcategories.men.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Women</DropdownMenuLabel>
                {lensesSubcategories.women.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Kids</DropdownMenuLabel>
                {lensesSubcategories.kids.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Other Options</DropdownMenuLabel>
                {lensesSubcategories.other.map((item) => (
                  <DropdownMenuItem key={item.name} asChild>
                    <Link href={item.href}>{item.name}</Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/lenses" className="font-medium text-primary">View All Lenses</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Link 
              href="/appointment" 
              className={`relative py-2 text-sm font-medium transition-colors ${isActive('/appointment') ? 'text-primary' : 'hover:text-primary'}`}
            >
              Appointment
              {isActive('/appointment') && (
                <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
              )}
            </Link>
            <Link 
              href="/contact" 
              className={`relative py-2 text-sm font-medium transition-colors ${isActive('/contact') ? 'text-primary' : 'hover:text-primary'}`}
            >
              Contact Us
              {isActive('/contact') && (
                <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
              )}
            </Link>
          </nav>
        </div>

        {/* Desktop Actions */}
        <div className="hidden lg:flex items-center space-x-4">
          <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(!isSearchOpen)}>
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">Account</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {user ? (
                <>
                  <DropdownMenuLabel>{user.fullName}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/account" className="flex items-center">
                      <User className="mr-2 h-4 w-4" />
                      <span>My Account</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/account?tab=orders" className="flex items-center">
                      <Package className="mr-2 h-4 w-4" />
                      <span>My Orders</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/account?tab=settings" className="flex items-center">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="flex items-center">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuItem asChild>
                    <Link href="/auth" className="flex items-center">
                      <LogIn className="mr-2 h-4 w-4" />
                      <span>Login</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/auth?tab=register" className="flex items-center">
                      <UserPlus className="mr-2 h-4 w-4" />
                      <span>Register</span>
                    </Link>
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          <Link href="/cart">
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {totalItems > 9 ? '9+' : totalItems}
                </span>
              )}
              <span className="sr-only">Cart</span>
            </Button>
          </Link>

          <ThemeToggle />
        </div>
      </div>

      {/* Search Bar */}
      {isSearchOpen && (
        <div className="py-4 px-4 bg-muted">
          <div className="container mx-auto">
            <form className="flex w-full max-w-lg mx-auto">
              <input
                type="search"
                placeholder="Search for products..."
                className="flex-1 min-w-0 px-4 py-2 border border-input bg-background rounded-l-md focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <Button type="submit" className="rounded-l-none">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </form>
          </div>
        </div>
      )}
    </header>
  );
}
