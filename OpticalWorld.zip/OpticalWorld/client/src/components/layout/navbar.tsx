import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

type NavCategory = {
  title: string;
  items: { name: string; href: string }[];
};

export default function Navbar() {
  const [location] = useLocation();

  const eyeglasses: NavCategory = {
    title: "Eyeglasses",
    items: [
      // For Men
      { name: "Men's Single Vision", href: "/eyeglasses?subCategory=prescribed&type=single+vision&gender=men" },
      { name: "Men's Bifocal Lenses", href: "/eyeglasses?subCategory=prescribed&type=bifocal&gender=men" },
      { name: "Men's Progressive Lenses", href: "/eyeglasses?subCategory=prescribed&type=progressive&gender=men" },
      { name: "Men's Fashion Frames", href: "/eyeglasses?subCategory=non-prescribed&type=fashion&gender=men" },
      { name: "Men's Blue Light Filtering", href: "/eyeglasses?subCategory=non-prescribed&type=blue+light+filtering&gender=men" },
      
      // For Women
      { name: "Women's Single Vision", href: "/eyeglasses?subCategory=prescribed&type=single+vision&gender=women" },
      { name: "Women's Bifocal Lenses", href: "/eyeglasses?subCategory=prescribed&type=bifocal&gender=women" },
      { name: "Women's Progressive Lenses", href: "/eyeglasses?subCategory=prescribed&type=progressive&gender=women" },
      { name: "Women's Fashion Frames", href: "/eyeglasses?subCategory=non-prescribed&type=fashion&gender=women" },
      { name: "Women's Blue Light Filtering", href: "/eyeglasses?subCategory=non-prescribed&type=blue+light+filtering&gender=women" },
      
      // For Kids
      { name: "Kids' Single Vision", href: "/eyeglasses?subCategory=prescribed&type=single+vision&gender=kids" },
      { name: "Kids' Fashion Frames", href: "/eyeglasses?subCategory=non-prescribed&type=fashion&gender=kids" },
      { name: "Kids' Blue Light Filtering", href: "/eyeglasses?subCategory=non-prescribed&type=blue+light+filtering&gender=kids" },
      
      // General options (without gender filter)
      { name: "Reading Glasses", href: "/eyeglasses?subCategory=prescribed&type=reading" },
      { name: "High-index Lenses", href: "/eyeglasses?subCategory=prescribed&type=high-index" },
      { name: "Gaming Glasses", href: "/eyeglasses?subCategory=non-prescribed&type=gaming" },
      { name: "Anti-fatigue Glasses", href: "/eyeglasses?subCategory=non-prescribed&type=anti-fatigue" },
    ]
  };

  const sunglasses: NavCategory = {
    title: "Sunglasses",
    items: [
      // For Men
      { name: "Men's Polarized Prescription", href: "/sunglasses?subCategory=prescribed&type=polarized+prescription&gender=men" },
      { name: "Men's Standard Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=standard&gender=men" },
      { name: "Men's Sports Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=sports&gender=men" },
      { name: "Men's Fashion Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=fashion&gender=men" },
      
      // For Women
      { name: "Women's Polarized Prescription", href: "/sunglasses?subCategory=prescribed&type=polarized+prescription&gender=women" },
      { name: "Women's Standard Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=standard&gender=women" },
      { name: "Women's Fashion Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=fashion&gender=women" },
      { name: "Women's Oversized Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=oversized&gender=women" },
      
      // For Kids
      { name: "Kids' Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=standard&gender=kids" },
      { name: "Kids' Sports Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=sports&gender=kids" },
      
      // General options (without gender filter)
      { name: "Photochromic Lenses", href: "/sunglasses?subCategory=prescribed&type=photochromic" },
      { name: "Polarized Sunglasses", href: "/sunglasses?subCategory=non-prescribed&type=polarized" },
    ]
  };

  const lenses: NavCategory = {
    title: "Lenses",
    items: [
      // For Men
      { name: "Men's Corrective Lenses", href: "/lenses?subCategory=prescribed&type=corrective&gender=men" },
      { name: "Men's Multifocal Lenses", href: "/lenses?subCategory=prescribed&type=multifocal&gender=men" },
      { name: "Men's Toric Lenses", href: "/lenses?subCategory=prescribed&type=toric&gender=men" },
      
      // For Women
      { name: "Women's Corrective Lenses", href: "/lenses?subCategory=prescribed&type=corrective&gender=women" },
      { name: "Women's Multifocal Lenses", href: "/lenses?subCategory=prescribed&type=multifocal&gender=women" },
      { name: "Women's Toric Lenses", href: "/lenses?subCategory=prescribed&type=toric&gender=women" },
      { name: "Women's Cosmetic Lenses", href: "/lenses?subCategory=non-prescribed&type=cosmetic&gender=women" },
      
      // For Kids
      { name: "Kids' Corrective Lenses", href: "/lenses?subCategory=prescribed&type=corrective&gender=kids" },
      { name: "Kids' Protective Lenses", href: "/lenses?subCategory=non-prescribed&type=uv+protective&gender=kids" },
      
      // General options (without gender filter)
      { name: "Cosmetic Contact Lenses", href: "/lenses?subCategory=non-prescribed&type=cosmetic" },
      { name: "Blue Light Blocking", href: "/lenses?subCategory=non-prescribed&type=blue+light+blocking" },
      { name: "UV Protective Lenses", href: "/lenses?subCategory=non-prescribed&type=uv+protective" },
    ]
  };

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <nav className="hidden lg:flex lg:flex-1 lg:items-center lg:justify-center">
      <div className="flex space-x-6">
        <Link 
          href="/" 
          className={`relative py-2 text-sm font-medium transition-colors ${isActive('/') ? 'text-primary' : 'hover:text-primary'}`}
        >
          Home
          {isActive('/') && (
            <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
          )}
        </Link>
        
        <div className="group relative">
          <Link 
            href="/eyeglasses" 
            className={`py-2 text-sm font-medium transition-colors ${location.startsWith('/eyeglasses') ? 'text-primary' : 'hover:text-primary'} flex items-center`}
          >
            Eyeglasses <i className="fas fa-chevron-down ml-1 text-xs"></i>
          </Link>
          {location.startsWith('/eyeglasses') && (
            <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
          )}
          <div className="invisible absolute left-0 mt-2 w-80 rounded-md bg-white dark:bg-gray-800 shadow-lg group-hover:visible transition-all opacity-0 group-hover:opacity-100 z-10">
            <div className="p-4">
              <h3 className="font-semibold border-b pb-2 mb-2">Men</h3>
              <ul className="space-y-1 mb-3">
                {eyeglasses.items.filter(item => item.href.includes('gender=men')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Women</h3>
              <ul className="space-y-1 mb-3">
                {eyeglasses.items.filter(item => item.href.includes('gender=women')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Kids</h3>
              <ul className="space-y-1 mb-3">
                {eyeglasses.items.filter(item => item.href.includes('gender=kids')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Other Options</h3>
              <ul className="space-y-1">
                {eyeglasses.items.filter(item => !item.href.includes('gender=')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        
        <div className="group relative">
          <Link 
            href="/sunglasses" 
            className={`py-2 text-sm font-medium transition-colors ${location.startsWith('/sunglasses') ? 'text-primary' : 'hover:text-primary'} flex items-center`}
          >
            Sunglasses <i className="fas fa-chevron-down ml-1 text-xs"></i>
          </Link>
          {location.startsWith('/sunglasses') && (
            <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
          )}
          <div className="invisible absolute left-0 mt-2 w-80 rounded-md bg-white dark:bg-gray-800 shadow-lg group-hover:visible transition-all opacity-0 group-hover:opacity-100 z-10">
            <div className="p-4">
              <h3 className="font-semibold border-b pb-2 mb-2">Men</h3>
              <ul className="space-y-1 mb-3">
                {sunglasses.items.filter(item => item.href.includes('gender=men')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Women</h3>
              <ul className="space-y-1 mb-3">
                {sunglasses.items.filter(item => item.href.includes('gender=women')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Kids</h3>
              <ul className="space-y-1 mb-3">
                {sunglasses.items.filter(item => item.href.includes('gender=kids')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Other Options</h3>
              <ul className="space-y-1">
                {sunglasses.items.filter(item => !item.href.includes('gender=')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        
        <div className="group relative">
          <Link 
            href="/lenses" 
            className={`py-2 text-sm font-medium transition-colors ${location.startsWith('/lenses') ? 'text-primary' : 'hover:text-primary'} flex items-center`}
          >
            Lenses <i className="fas fa-chevron-down ml-1 text-xs"></i>
          </Link>
          {location.startsWith('/lenses') && (
            <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
          )}
          <div className="invisible absolute left-0 mt-2 w-80 rounded-md bg-white dark:bg-gray-800 shadow-lg group-hover:visible transition-all opacity-0 group-hover:opacity-100 z-10">
            <div className="p-4">
              <h3 className="font-semibold border-b pb-2 mb-2">Men</h3>
              <ul className="space-y-1 mb-3">
                {lenses.items.filter(item => item.href.includes('gender=men')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Women</h3>
              <ul className="space-y-1 mb-3">
                {lenses.items.filter(item => item.href.includes('gender=women')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Kids</h3>
              <ul className="space-y-1 mb-3">
                {lenses.items.filter(item => item.href.includes('gender=kids')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <h3 className="font-semibold border-b pb-2 mb-2">Other Options</h3>
              <ul className="space-y-1">
                {lenses.items.filter(item => !item.href.includes('gender=')).map((item) => (
                  <li key={item.name}>
                    <Link href={item.href} className="block py-1 hover:text-primary">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        
        <Link 
          href="/appointment" 
          className={`relative py-2 text-sm font-medium transition-colors ${isActive('/appointment') ? 'text-primary' : 'hover:text-primary'}`}
        >
          Appointment
          {isActive('/appointment') && (
            <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
          )}
        </Link>
        
        <Link 
          href="/contact" 
          className={`relative py-2 text-sm font-medium transition-colors ${isActive('/contact') ? 'text-primary' : 'hover:text-primary'}`}
        >
          Contact Us
          {isActive('/contact') && (
            <span className="absolute left-0 bottom-0 h-0.5 w-full bg-primary" />
          )}
        </Link>
      </div>
    </nav>
  );
}
