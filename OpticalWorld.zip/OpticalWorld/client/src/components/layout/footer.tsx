import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <h2 className="text-xl font-bold mb-4 flex items-center">
              <i className="fas fa-glasses mr-2"></i>
              Ainak
            </h2>
            <p className="text-gray-400 mb-6 max-w-md">
              Ainak is your trusted optical store providing premium eyewear solutions with a focus on quality, style, and eye health. We've been serving customers since 2005.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-primary hover:bg-primary/80 text-white p-2 rounded-full transition">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="bg-primary hover:bg-primary/80 text-white p-2 rounded-full transition">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="bg-primary hover:bg-primary/80 text-white p-2 rounded-full transition">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="bg-primary hover:bg-primary/80 text-white p-2 rounded-full transition">
                <i className="fab fa-pinterest"></i>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-3">
              <li><Link href="/" className="text-gray-400 hover:text-primary transition">Home</Link></li>
              <li><Link href="/" className="text-gray-400 hover:text-primary transition">About Us</Link></li>
              <li><Link href="/eyeglasses" className="text-gray-400 hover:text-primary transition">Shop</Link></li>
              <li><Link href="/appointment" className="text-gray-400 hover:text-primary transition">Book Appointment</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-primary transition">Contact Us</Link></li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Products</h3>
            <ul className="space-y-3">
              <li><Link href="/eyeglasses" className="text-gray-400 hover:text-primary transition">Eyeglasses</Link></li>
              <li><Link href="/sunglasses" className="text-gray-400 hover:text-primary transition">Sunglasses</Link></li>
              <li><Link href="/lenses" className="text-gray-400 hover:text-primary transition">Contact Lenses</Link></li>
              <li><Link href="/eyeglasses?type=reading" className="text-gray-400 hover:text-primary transition">Reading Glasses</Link></li>
              <li><Link href="/eyeglasses" className="text-gray-400 hover:text-primary transition">Accessories</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3 text-primary"></i>
                <span className="text-gray-400">123 Vision Street, Optical City, OC 12345</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-phone-alt mr-3 text-primary"></i>
                <span className="text-gray-400">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-envelope mr-3 text-primary"></i>
                <span className="text-gray-400">info@ainakoptical.com</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-clock mr-3 text-primary"></i>
                <span className="text-gray-400">Mon-Sat: 9AM - 6PM</span>
              </li>
            </ul>
          </div>
        </div>

        <hr className="border-gray-800 my-8" />

        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Ainak Optical Store. All Rights Reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm">Terms of Service</a>
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm">Shipping Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
