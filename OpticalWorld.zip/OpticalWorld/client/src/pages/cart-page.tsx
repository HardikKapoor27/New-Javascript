import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useCart } from "@/hooks/use-cart";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle2, ShoppingCart, ArrowLeft, ShoppingBag, Loader2 } from "lucide-react";
import CartItemComponent from "@/components/cart/cart-item";
import { Order } from "@shared/schema";

export default function CartPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { cartItems, totalItems, totalPrice, clearCartMutation } = useCart();
  const [shippingAddress, setShippingAddress] = useState("");
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderId, setOrderId] = useState<number | null>(null);
  
  const { data: placedOrder, isLoading: isLoadingOrder } = useQuery<Order & { items: any[] }>({
    queryKey: ["/api/orders", orderId],
    enabled: orderId !== null,
  });
  
  // Checkout mutation
  const checkoutMutation = useMutation({
    mutationFn: async () => {
      const orderData = {
        shippingAddress,
      };
      
      const res = await apiRequest("POST", "/api/orders", orderData);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Order Placed Successfully",
        description: "Thank you for your purchase!",
      });
      setOrderId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Checkout Failed",
        description: error.message,
        variant: "destructive",
      });
      setIsCheckingOut(false);
    },
  });
  
  const handleCheckout = () => {
    if (!shippingAddress.trim()) {
      toast({
        title: "Shipping Address Required",
        description: "Please enter your shipping address to continue.",
        variant: "destructive",
      });
      return;
    }
    
    setIsCheckingOut(true);
    checkoutMutation.mutate();
  };
  
  const handleContinueShopping = () => {
    setLocation("/");
  };
  
  // Display confirmation if order was placed
  if (orderId !== null) {
    return (
      <>
        <Helmet>
          <title>Order Confirmation | Ainak: The Optical Store</title>
          <meta name="description" content="Your order has been confirmed. Thank you for shopping with Ainak Optical Store." />
        </Helmet>
        
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            <Card className="mb-8">
              <CardHeader className="text-center">
                <div className="w-12 h-12 rounded-full bg-primary/20 mx-auto flex items-center justify-center mb-4">
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-2xl">Order Confirmed!</CardTitle>
                <CardDescription>
                  Thank you for your purchase. We'll process your order right away.
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                {isLoadingOrder ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : placedOrder ? (
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-semibold mb-2">Order Details</h3>
                      <p className="text-sm text-muted-foreground">Order ID: #{placedOrder.id}</p>
                      <p className="text-sm text-muted-foreground">Date: {new Date(placedOrder.createdAt).toLocaleDateString()}</p>
                      <p className="text-sm text-muted-foreground">Status: {placedOrder.status.charAt(0).toUpperCase() + placedOrder.status.slice(1)}</p>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold mb-2">Shipping Address</h3>
                      <p className="text-sm text-muted-foreground">{placedOrder.shippingAddress}</p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-semibold mb-4">Order Summary</h3>
                      
                      <div className="space-y-3">
                        {placedOrder.items.map((item) => (
                          <div key={item.id} className="flex justify-between">
                            <div>
                              <p>{item.product.name} × {item.quantity}</p>
                              <p className="text-sm text-muted-foreground">{item.product.category} - {item.product.type}</p>
                            </div>
                            <p>${(item.price * item.quantity).toFixed(2)}</p>
                          </div>
                        ))}
                      </div>
                      
                      <Separator className="my-4" />
                      
                      <div className="flex justify-between font-semibold">
                        <p>Total</p>
                        <p>${placedOrder.totalAmount.toFixed(2)}</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-center py-4">Order details could not be loaded.</p>
                )}
              </CardContent>
              
              <CardFooter className="flex flex-col md:flex-row gap-4 justify-center">
                <Button onClick={handleContinueShopping} className="w-full md:w-auto">
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Continue Shopping
                </Button>
                <Button variant="outline" asChild className="w-full md:w-auto">
                  <Link href="/account?tab=orders">
                    View All Orders
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Shopping Cart | Ainak: The Optical Store</title>
        <meta name="description" content="View and manage items in your cart. Proceed to checkout to complete your purchase of premium eyewear." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 font-heading">Shopping Cart</h1>
        
        {cartItems.length === 0 ? (
          <Card className="max-w-3xl mx-auto">
            <CardContent className="pt-10 flex flex-col items-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <ShoppingCart className="h-8 w-8 text-muted-foreground" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Your cart is empty</h2>
              <p className="text-muted-foreground mb-6">
                Looks like you haven't added any products to your cart yet.
              </p>
              <Button onClick={handleContinueShopping}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Continue Shopping
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Cart Items ({totalItems})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    {cartItems.map((item) => (
                      <CartItemComponent key={item.id} item={item} />
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={handleContinueShopping}
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Continue Shopping
                  </Button>
                  <Button 
                    variant="destructive" 
                    onClick={() => clearCartMutation.mutate()}
                    disabled={clearCartMutation.isPending}
                  >
                    {clearCartMutation.isPending ? "Clearing..." : "Clear Cart"}
                  </Button>
                </CardFooter>
              </Card>
            </div>
            
            <div>
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${totalPrice.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between font-semibold">
                    <span>Total</span>
                    <span>${totalPrice.toFixed(2)}</span>
                  </div>
                  
                  <div className="pt-4">
                    <label className="block mb-2 text-sm font-medium">
                      Shipping Address
                    </label>
                    <Input 
                      placeholder="Enter your complete shipping address"
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      className="mb-4"
                    />
                    
                    <Button 
                      className="w-full" 
                      onClick={handleCheckout}
                      disabled={isCheckingOut || checkoutMutation.isPending}
                    >
                      {isCheckingOut || checkoutMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        "Checkout"
                      )}
                    </Button>
                    
                    <p className="text-xs text-muted-foreground mt-4 text-center">
                      Secure payment processing. All major credit cards accepted.
                    </p>
                    <div className="flex justify-center mt-2 space-x-2">
                      <i className="fab fa-cc-visa text-2xl"></i>
                      <i className="fab fa-cc-mastercard text-2xl"></i>
                      <i className="fab fa-cc-amex text-2xl"></i>
                      <i className="fab fa-cc-paypal text-2xl"></i>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
