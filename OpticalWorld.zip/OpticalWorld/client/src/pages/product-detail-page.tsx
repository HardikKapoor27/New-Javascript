import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Helmet } from "react-helmet";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  ChevronRight,
  Minus,
  Plus,
  Heart,
  Share2,
  ShoppingCart,
  Check,
  Star,
  Loader2,
  ArrowLeft,
} from "lucide-react";
import ProductCard from "@/components/products/product-card";

export default function ProductDetailPage() {
  const [, params] = useRoute("/product/:id");
  const productId = params?.id ? parseInt(params.id) : 0;
  const { user } = useAuth();
  const { addToCartMutation } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [isAddedToCart, setIsAddedToCart] = useState(false);
  const [activeTab, setActiveTab] = useState("description");
  
  // Fetch product details
  const { data: product, isLoading: isLoadingProduct } = useQuery<Product>({
    queryKey: [`/api/products/${productId}`],
  });
  
  // Fetch related products
  const { data: relatedProducts = [], isLoading: isLoadingRelated } = useQuery<Product[]>({
    queryKey: ["/api/products", { 
      category: product?.category,
      limit: 4
    }],
    enabled: !!product,
  });
  
  const handleQuantityChange = (amount: number) => {
    const newQuantity = quantity + amount;
    if (newQuantity >= 1) {
      setQuantity(newQuantity);
    }
  };
  
  const handleAddToCart = () => {
    if (!user) return;
    
    addToCartMutation.mutate(
      { productId, quantity },
      {
        onSuccess: () => {
          setIsAddedToCart(true);
          setTimeout(() => setIsAddedToCart(false), 2000);
        }
      }
    );
  };
  
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="h-4 w-4 fill-yellow-400 text-yellow-400" />);
    }

    if (hasHalfStar) {
      stars.push(
        <span key="half-star" className="relative">
          <Star className="h-4 w-4 text-yellow-400" />
          <Star className="absolute top-0 left-0 h-4 w-4 fill-yellow-400 text-yellow-400 overflow-hidden" style={{ clipPath: 'inset(0 50% 0 0)' }} />
        </span>
      );
    }

    const remaining = 5 - stars.length;
    for (let i = 0; i < remaining; i++) {
      stars.push(<Star key={`empty-${i}`} className="h-4 w-4 text-yellow-400" />);
    }

    return (
      <div className="flex items-center">
        {stars}
        <span className="ml-2 text-sm text-muted-foreground">({rating})</span>
      </div>
    );
  };
  
  // Format category and type for display
  const formatText = (text: string) => {
    return text
      .split(/[-\s+]/)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };
  
  if (isLoadingProduct) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
        <p className="text-muted-foreground mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/eyeglasses">Back to Products</Link>
        </Button>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>{product.name} | Ainak: The Optical Store</title>
        <meta name="description" content={product.description} />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumbs */}
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Home</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <ChevronRight className="h-4 w-4" />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink href={`/${product.category}`}>
                {formatText(product.category)}
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <ChevronRight className="h-4 w-4" />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink>
                {product.name}
              </BreadcrumbLink>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        
        {/* Back button for mobile */}
        <div className="mb-4 lg:hidden">
          <Button variant="ghost" size="sm" asChild>
            <Link href={`/${product.category}`}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to {formatText(product.category)}
            </Link>
          </Button>
        </div>
        
        {/* Product details */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Product image */}
          <div className="relative">
            <div className="aspect-square overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800">
              <img
                src={product.imageUrl}
                alt={product.name}
                className="h-full w-full object-cover"
              />
            </div>
            
            {product.isNew && (
              <Badge className="absolute top-4 left-4 bg-primary hover:bg-primary">
                New Arrival
              </Badge>
            )}
            {product.isBestseller && (
              <Badge className="absolute top-4 left-4" variant="secondary">
                Bestseller
              </Badge>
            )}
          </div>
          
          {/* Product info */}
          <div>
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              {renderStars(product.rating)}
            </div>
            
            <div className="mb-6">
              {product.discountPrice ? (
                <div className="flex items-center">
                  <span className="text-3xl font-bold mr-3">${product.discountPrice.toFixed(2)}</span>
                  <span className="text-xl text-muted-foreground line-through">${product.price.toFixed(2)}</span>
                  <Badge className="ml-3 bg-green-500 hover:bg-green-500">
                    Save ${(product.price - product.discountPrice).toFixed(2)}
                  </Badge>
                </div>
              ) : (
                <span className="text-3xl font-bold">${product.price.toFixed(2)}</span>
              )}
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <span className="text-sm text-muted-foreground">Category</span>
                <p className="font-medium">{formatText(product.category)}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Type</span>
                <p className="font-medium">{formatText(product.type)}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Subcategory</span>
                <p className="font-medium">{product.subCategory === "prescribed" ? "Prescription" : "Non-Prescription"}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Availability</span>
                <p className={`font-medium ${product.inStock ? "text-green-600" : "text-red-600"}`}>
                  {product.inStock ? "In Stock" : "Out of Stock"}
                </p>
              </div>
            </div>
            
            <Separator className="my-6" />
            
            <div className="mb-6">
              <p className="text-muted-foreground mb-2">Description:</p>
              <p>{product.description}</p>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-6">
              {product.tags && product.tags.map(tag => (
                <Badge key={tag} variant="outline">
                  {formatText(tag)}
                </Badge>
              ))}
            </div>
            
            <div className="flex items-center space-x-6 mb-8">
              <div className="flex items-center border rounded-md">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleQuantityChange(-1)}
                  disabled={quantity <= 1}
                  className="h-10 w-10 rounded-r-none"
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <div className="h-10 w-12 flex items-center justify-center text-center">
                  {quantity}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleQuantityChange(1)}
                  className="h-10 w-10 rounded-l-none"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              
              <Button
                className="flex-1"
                onClick={handleAddToCart}
                disabled={!product.inStock || addToCartMutation.isPending || isAddedToCart}
              >
                {isAddedToCart ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Added to Cart
                  </>
                ) : addToCartMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Add to Cart
                  </>
                )}
              </Button>
            </div>
            
            <div className="flex space-x-4">
              <Button variant="outline" className="flex-1">
                <Heart className="mr-2 h-4 w-4" />
                Add to Wishlist
              </Button>
              <Button variant="outline" className="flex-1">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </div>
        </div>
        
        {/* Product tabs */}
        <div className="mb-16">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="details">Details & Features</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="pt-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Product Description</h3>
                  <p className="mb-4">{product.description}</p>
                  <p>
                    Experience superior quality and comfort with our {product.name}. 
                    Designed for everyday wear, these {product.category} provide excellent
                    {product.subCategory === "prescribed" ? " vision correction" : " style and protection"}.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="details" className="pt-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Product Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Specifications</h4>
                      <ul className="space-y-2">
                        <li className="flex justify-between">
                          <span className="text-muted-foreground">Category:</span>
                          <span>{formatText(product.category)}</span>
                        </li>
                        <li className="flex justify-between">
                          <span className="text-muted-foreground">Type:</span>
                          <span>{formatText(product.type)}</span>
                        </li>
                        <li className="flex justify-between">
                          <span className="text-muted-foreground">Prescription Type:</span>
                          <span>{product.subCategory === "prescribed" ? "Prescription" : "Non-Prescription"}</span>
                        </li>
                        <li className="flex justify-between">
                          <span className="text-muted-foreground">Material:</span>
                          <span>
                            {product.tags?.find(tag => 
                              ["titanium", "acetate", "plastic", "metal"].includes(tag)
                            ) || "Premium Quality"}
                          </span>
                        </li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Features</h4>
                      <ul className="space-y-2">
                        {product.tags && product.tags.map(tag => (
                          <li key={tag} className="flex items-center">
                            <Check className="h-4 w-4 text-green-500 mr-2" />
                            <span>{formatText(tag)}</span>
                          </li>
                        ))}
                        <li className="flex items-center">
                          <Check className="h-4 w-4 text-green-500 mr-2" />
                          <span>Durable Construction</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="h-4 w-4 text-green-500 mr-2" />
                          <span>Comfortable Fit</span>
                        </li>
                        <li className="flex items-center">
                          <Check className="h-4 w-4 text-green-500 mr-2" />
                          <span>30-Day Warranty</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="reviews" className="pt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold">Customer Reviews</h3>
                    <Button>Write a Review</Button>
                  </div>
                  
                  <div className="mb-8">
                    <div className="flex items-center mb-2">
                      {renderStars(product.rating)}
                      <span className="ml-2">Based on 24 reviews</span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-4">
                        <div className="flex items-center">
                          <span className="w-16">5 stars</span>
                          <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                            <div className="h-full rounded-full bg-yellow-400" style={{ width: '70%' }}></div>
                          </div>
                          <span className="w-10 text-right">70%</span>
                        </div>
                        <div className="flex items-center">
                          <span className="w-16">4 stars</span>
                          <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                            <div className="h-full rounded-full bg-yellow-400" style={{ width: '20%' }}></div>
                          </div>
                          <span className="w-10 text-right">20%</span>
                        </div>
                        <div className="flex items-center">
                          <span className="w-16">3 stars</span>
                          <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                            <div className="h-full rounded-full bg-yellow-400" style={{ width: '5%' }}></div>
                          </div>
                          <span className="w-10 text-right">5%</span>
                        </div>
                        <div className="flex items-center">
                          <span className="w-16">2 stars</span>
                          <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                            <div className="h-full rounded-full bg-yellow-400" style={{ width: '3%' }}></div>
                          </div>
                          <span className="w-10 text-right">3%</span>
                        </div>
                        <div className="flex items-center">
                          <span className="w-16">1 star</span>
                          <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                            <div className="h-full rounded-full bg-yellow-400" style={{ width: '2%' }}></div>
                          </div>
                          <span className="w-10 text-right">2%</span>
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-muted-foreground">
                          Most customers are highly satisfied with this product, highlighting its comfort, 
                          quality construction, and stylish design. A few customers mentioned minor 
                          fit issues, but overall the feedback is very positive.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <Separator className="mb-6" />
                  
                  <div className="space-y-6">
                    <div className="border rounded-lg p-4">
                      <div className="flex justify-between mb-2">
                        <div className="flex items-center">
                          <div className="mr-4 rounded-full bg-primary/20 h-10 w-10 flex items-center justify-center">
                            <span className="font-medium text-primary">SJ</span>
                          </div>
                          <div>
                            <h4 className="font-medium">Sarah Johnson</h4>
                            <p className="text-sm text-muted-foreground">Verified Buyer</p>
                          </div>
                        </div>
                        <div className="flex">
                          {Array(5).fill(0).map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm mb-2">Purchased 2 months ago</p>
                      <h5 className="font-medium mb-1">Excellent quality and comfort</h5>
                      <p>
                        I absolutely love these! The quality is outstanding and they're so comfortable
                        I forget I'm wearing them. The style is exactly as pictured and I've received
                        many compliments. Highly recommended!
                      </p>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <div className="flex justify-between mb-2">
                        <div className="flex items-center">
                          <div className="mr-4 rounded-full bg-primary/20 h-10 w-10 flex items-center justify-center">
                            <span className="font-medium text-primary">JW</span>
                          </div>
                          <div>
                            <h4 className="font-medium">James Wilson</h4>
                            <p className="text-sm text-muted-foreground">Verified Buyer</p>
                          </div>
                        </div>
                        <div className="flex">
                          {Array(4).fill(0).map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          ))}
                          <Star className="h-4 w-4 text-yellow-400" />
                        </div>
                      </div>
                      <p className="text-sm mb-2">Purchased 1 month ago</p>
                      <h5 className="font-medium mb-1">Great product with minor fit issues</h5>
                      <p>
                        Overall I'm very happy with this purchase. The quality is excellent and they look
                        great. The only reason for 4 stars is they needed some adjustment to fit perfectly,
                        but once that was done they've been fantastic.
                      </p>
                    </div>
                    
                    <Button variant="outline" className="w-full">Load More Reviews</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Related products */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Related Products</h2>
          
          {isLoadingRelated ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm animate-pulse">
                  <div className="h-64 bg-gray-200 dark:bg-gray-700"></div>
                  <div className="p-4">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-4"></div>
                    <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts
                .filter(p => p.id !== product.id)
                .slice(0, 4)
                .map((relatedProduct) => (
                  <ProductCard key={relatedProduct.id} product={relatedProduct} />
                ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
