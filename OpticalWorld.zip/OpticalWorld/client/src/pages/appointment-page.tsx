import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { insertAppointmentSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, Check, Loader2 } from "lucide-react";

// Extend the appointment schema for form validation
const appointmentFormSchema = insertAppointmentSchema
  .omit({ userId: true, status: true })
  .extend({
    date: z.date({
      required_error: "Please select a date for your appointment",
    }),
    time: z.string({
      required_error: "Please select a time for your appointment",
    }),
    agreeToTerms: z.boolean().refine(val => val === true, {
      message: "You must agree to the terms and conditions",
    }),
  });

type AppointmentFormValues = z.infer<typeof appointmentFormSchema>;

const eyeTestTypes = [
  {
    id: "comprehensive",
    name: "Comprehensive Eye Exam",
    description: "Complete evaluation of your eye health and vision with our skilled optometrists.",
    duration: "45-60 minutes",
  },
  {
    id: "prescription",
    name: "Prescription Update",
    description: "Get your prescription refreshed to ensure optimal vision with your eyewear.",
    duration: "30 minutes",
  },
  {
    id: "contact-lens",
    name: "Contact Lens Fitting",
    description: "Professional fitting and assessment for new or existing contact lens wearers.",
    duration: "30-45 minutes",
  },
  {
    id: "eye-pressure",
    name: "Eye Pressure Test (Glaucoma)",
    description: "Non-invasive test to measure intraocular pressure to screen for glaucoma.",
    duration: "15 minutes",
  },
  {
    id: "retinal-imaging",
    name: "Retinal Imaging",
    description: "Detailed images of your retina to detect and monitor eye conditions.",
    duration: "20 minutes",
  },
  {
    id: "pediatric",
    name: "Pediatric Eye Exam",
    description: "Specialized eye exam for children to check visual development and eye health.",
    duration: "30-45 minutes",
  },
];

const timeSlots = [
  "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
  "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM", "2:00 PM", "2:30 PM",
  "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM", "5:00 PM"
];

export default function AppointmentPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Set up form with default values
  const form = useForm<AppointmentFormValues>({
    resolver: zodResolver(appointmentFormSchema),
    defaultValues: {
      name: user?.fullName || "",
      email: user?.email || "",
      phone: user?.phone || "",
      testType: "",
      previousExam: "",
      notes: "",
      agreeToTerms: false,
    },
  });

  // Appointment submission mutation
  const appointmentMutation = useMutation({
    mutationFn: async (data: AppointmentFormValues) => {
      // Combine date and time into a single Date object
      const [hours, minutes] = data.time.match(/(\d+):(\d+)/)!.slice(1, 3).map(Number);
      const isPM = data.time.includes("PM");
      const adjustedHours = isPM && hours !== 12 ? hours + 12 : hours;
      
      const appointmentDateTime = new Date(data.date);
      appointmentDateTime.setHours(adjustedHours, minutes);
      
      const appointmentData = {
        userId: user?.id || 0, // Use 0 for non-authenticated users
        name: data.name,
        email: data.email,
        phone: data.phone,
        date: appointmentDateTime.toISOString(),
        testType: data.testType,
        previousExam: data.previousExam,
        notes: data.notes,
        status: "pending"
      };
      
      const res = await apiRequest("POST", "/api/appointments", appointmentData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Appointment Scheduled",
        description: "Your appointment has been successfully scheduled. We'll contact you shortly to confirm.",
      });
      setIsSubmitted(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Error Scheduling Appointment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: AppointmentFormValues) {
    appointmentMutation.mutate(data);
  }

  // Determine which dates are disabled (past dates and Sundays)
  const isDateDisabled = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Disable past dates and Sundays (day 0)
    return date < today || date.getDay() === 0;
  };

  return (
    <>
      <Helmet>
        <title>Book an Eye Appointment | Ainak: The Optical Store</title>
        <meta name="description" content="Schedule an eye exam, prescription update, or contact lens fitting with our experienced optometrists. Regular eye check-ups are essential for maintaining good vision." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold mb-4 font-heading">Book Your Eye Appointment</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Regular eye check-ups are essential for maintaining good vision and detecting potential issues early. Our expert optometrists use advanced technology to ensure your eyes stay healthy.
            </p>
          </div>
          
          {/* Eye Test Information Section */}
          <div className="mb-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {eyeTestTypes.map((test) => (
              <Card key={test.id} className="h-full">
                <CardHeader>
                  <CardTitle className="text-lg">{test.name}</CardTitle>
                  <CardDescription>Duration: {test.duration}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {test.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {isSubmitted ? (
            <Card className="mb-12">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                  <Check className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-center">Appointment Request Submitted</CardTitle>
                <CardDescription className="text-center">
                  Thank you for scheduling an appointment with us
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <p className="mb-6">
                  We've received your appointment request and will contact you shortly to confirm the details.
                  If you have any questions, please contact our customer service.
                </p>
                <Button onClick={() => setIsSubmitted(false)}>Book Another Appointment</Button>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Appointment Request Form</CardTitle>
                <CardDescription>
                  Fill out the form below to request an appointment with one of our optometrists
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="Enter your email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="testType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Appointment Type</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select appointment type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {eyeTestTypes.map((test) => (
                                  <SelectItem key={test.id} value={test.id}>
                                    {test.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="date"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Appointment Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={`w-full pl-3 text-left font-normal ${!field.value && "text-muted-foreground"}`}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={isDateDisabled}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="time"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Appointment Time</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a time" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {timeSlots.map((time) => (
                                  <SelectItem key={time} value={time}>
                                    {time}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="previousExam"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Previous Eye Exam (if any)</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., 6 months ago at Vision Center" {...field} />
                          </FormControl>
                          <FormDescription>
                            Let us know when and where you had your last eye examination
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Additional Notes</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Any specific concerns or information you'd like us to know" 
                              className="min-h-[100px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Include any concerns, symptoms, or specific requirements
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="agreeToTerms"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <input
                              type="checkbox"
                              checked={field.value}
                              onChange={field.onChange}
                              className="form-checkbox h-5 w-5 text-primary rounded border-gray-300 focus:ring-primary"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              I agree to the terms and conditions and privacy policy
                            </FormLabel>
                            <FormDescription>
                              By scheduling an appointment, you agree to our cancellation policy.
                            </FormDescription>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={appointmentMutation.isPending}
                    >
                      {appointmentMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        "Schedule Appointment"
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
