import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import ProductFilter from "@/components/products/product-filter";
import ProductCard from "@/components/products/product-card";
import { Helmet } from "react-helmet";
import { 
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { ChevronRight } from "lucide-react";

export default function SunglassesPage() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  
  const [filters, setFilters] = useState({
    subCategory: searchParams.get("subCategory") || undefined,
    type: searchParams.get("type") || undefined,
    minPrice: searchParams.get("minPrice") ? Number(searchParams.get("minPrice")) : undefined,
    maxPrice: searchParams.get("maxPrice") ? Number(searchParams.get("maxPrice")) : undefined,
    sort: searchParams.get("sort") || undefined
  });
  
  // Derive API query parameters from filters
  const queryParams: any = {
    category: "sunglasses",
  };
  
  if (filters.subCategory) queryParams.subCategory = filters.subCategory;
  if (filters.type) queryParams.type = filters.type;
  
  if (filters.sort) {
    switch (filters.sort) {
      case "price-low":
        queryParams.sortBy = "price";
        queryParams.sortOrder = "asc";
        break;
      case "price-high":
        queryParams.sortBy = "price";
        queryParams.sortOrder = "desc";
        break;
      case "newest":
        queryParams.sortBy = "createdAt";
        queryParams.sortOrder = "desc";
        break;
      case "rating":
        queryParams.sortBy = "rating";
        queryParams.sortOrder = "desc";
        break;
      // Case "featured" is the default, no sorting needed
    }
  }
  
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products", queryParams],
  });
  
  // Apply price filter client-side
  const filteredProducts = products.filter(product => {
    if (filters.minPrice !== undefined && filters.maxPrice !== undefined) {
      const price = product.discountPrice || product.price;
      return price >= filters.minPrice && price <= filters.maxPrice;
    }
    return true;
  });
  
  const handleFilterChange = (newFilters: any) => {
    setFilters({ ...filters, ...newFilters });
  };
  
  // Get page title and description based on filters
  const getPageTitle = () => {
    if (filters.type) {
      return `${filters.type.split('+').map((word: string) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} Sunglasses`;
    }
    if (filters.subCategory === "prescribed") return "Prescription Sunglasses";
    if (filters.subCategory === "non-prescribed") return "Non-Prescription Sunglasses";
    return "Sunglasses Collection";
  };
  
  const getPageDescription = () => {
    if (filters.type) {
      const typeFormatted = filters.type.split('+').map((word: string) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
      return `Shop our selection of ${typeFormatted} sunglasses. Protect your eyes in style with our premium UV-blocking lenses.`;
    }
    if (filters.subCategory === "prescribed") {
      return "Browse our collection of prescription sunglasses including polarized and photochromic options for optimal vision and sun protection.";
    }
    if (filters.subCategory === "non-prescribed") {
      return "Explore our non-prescription sunglasses including standard, polarized, sports, and fashion styles for every occasion.";
    }
    return "Shop our full collection of sunglasses for men, women, and children. Find prescription and non-prescription options with UV protection and polarized lenses.";
  };
  
  return (
    <>
      <Helmet>
        <title>{getPageTitle()} | Ainak: The Optical Store</title>
        <meta name="description" content={getPageDescription()} />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Home</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator>
              <ChevronRight className="h-4 w-4" />
            </BreadcrumbSeparator>
            <BreadcrumbItem>
              <BreadcrumbLink href="/sunglasses">Sunglasses</BreadcrumbLink>
            </BreadcrumbItem>
            {filters.subCategory && (
              <>
                <BreadcrumbSeparator>
                  <ChevronRight className="h-4 w-4" />
                </BreadcrumbSeparator>
                <BreadcrumbItem>
                  <BreadcrumbLink href={`/sunglasses?subCategory=${filters.subCategory}`}>
                    {filters.subCategory === "prescribed" ? "Prescription" : "Non-Prescription"}
                  </BreadcrumbLink>
                </BreadcrumbItem>
              </>
            )}
            {filters.type && (
              <>
                <BreadcrumbSeparator>
                  <ChevronRight className="h-4 w-4" />
                </BreadcrumbSeparator>
                <BreadcrumbItem>
                  <BreadcrumbLink>
                    {filters.type.split('+').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                  </BreadcrumbLink>
                </BreadcrumbItem>
              </>
            )}
          </BreadcrumbList>
        </Breadcrumb>
        
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 font-heading">{getPageTitle()}</h1>
          <p className="text-muted-foreground">{getPageDescription()}</p>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="w-full lg:w-1/4">
            <ProductFilter 
              category="sunglasses"
              currentFilters={filters}
              onFilterChange={handleFilterChange}
            />
          </div>
          
          <div className="w-full lg:w-3/4">
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array(6).fill(0).map((_, i) => (
                  <div key={i} className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm animate-pulse">
                    <div className="h-64 bg-gray-200 dark:bg-gray-700"></div>
                    <div className="p-4">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-4"></div>
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold mb-2">No products found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your filters or browse our other categories.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
