import HeroSection from "@/components/home/hero-section";
import AboutSection from "@/components/home/about-section";
import AppointmentCTA from "@/components/home/appointment-cta";
import OffersSection from "@/components/home/offers-section";
import TrendingCollection from "@/components/home/trending-collection";
import TestimonialSection from "@/components/home/testimonial-section";
import NewsletterSignup from "@/components/home/newsletter-signup";
import { Helmet } from "react-helmet";

export default function HomePage() {
  return (
    <>
      <Helmet>
        <title>Ainak: The Optical Store - Premium Eyewear</title>
        <meta name="description" content="Discover premium eyeglasses, sunglasses, and contact lenses at Ainak Optical Store. Quality eyewear, expert eye care, and stylish frames for every face." />
      </Helmet>
      
      <div className="flex flex-col min-h-screen">
        <main>
          <HeroSection />
          <AboutSection />
          <AppointmentCTA />
          <OffersSection />
          <TrendingCollection />
          <TestimonialSection />
          <NewsletterSignup />
        </main>
      </div>
    </>
  );
}
