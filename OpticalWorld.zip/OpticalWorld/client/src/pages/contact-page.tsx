import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { insertContactSubmissionSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Check, Loader2, MapPin, Phone, Mail, Clock } from "lucide-react";

// Contact form schema
const contactFormSchema = insertContactSubmissionSchema;

type ContactFormValues = z.infer<typeof contactFormSchema>;

export default function ContactPage() {
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Set up form with default values
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
    },
  });

  // Contact form submission mutation
  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormValues) => {
      const res = await apiRequest("POST", "/api/contact", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Thank you for contacting us. We'll get back to you shortly.",
      });
      setIsSubmitted(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Error Sending Message",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: ContactFormValues) {
    contactMutation.mutate(data);
  }
  
  const storeLocations = [
    {
      id: 1,
      name: "Main Store",
      address: "123 Vision Street, Optical City, OC 12345",
      phone: "+1 (555) 123-4567",
      email: "mainstore@ainakoptical.com",
      hours: "Monday - Saturday: 9AM - 6PM",
    },
    {
      id: 2,
      name: "Downtown Branch",
      address: "456 Eyewear Avenue, Metro District, MD 67890",
      phone: "+1 (555) 987-6543",
      email: "downtown@ainakoptical.com",
      hours: "Monday - Friday: 8AM - 7PM, Saturday: 10AM - 4PM",
    },
    {
      id: 3,
      name: "Westside Mall Location",
      address: "789 Shopping Center, Westside Mall, WM 54321",
      phone: "+1 (555) 456-7890",
      email: "westside@ainakoptical.com",
      hours: "Monday - Sunday: 10AM - 8PM",
    },
  ];

  return (
    <>
      <Helmet>
        <title>Contact Us | Ainak: The Optical Store</title>
        <meta name="description" content="Get in touch with Ainak Optical Store. Visit our stores, call us, or send a message. We're here to assist with all your eyewear and eye care needs." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold mb-4 font-heading">Contact Us</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We're here to help with all your eyewear and eye care needs. Contact us through any of the methods below or visit one of our store locations.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <div>
              <h2 className="text-2xl font-semibold mb-6">Our Stores</h2>
              
              <div className="space-y-8">
                {storeLocations.map((location) => (
                  <Card key={location.id} className="relative">
                    <CardContent className="p-6">
                      <h3 className="text-xl font-medium mb-3">{location.name}</h3>
                      
                      <div className="space-y-4">
                        <div className="flex items-start">
                          <MapPin className="h-5 w-5 text-primary mr-3 mt-0.5" />
                          <p>{location.address}</p>
                        </div>
                        
                        <div className="flex items-center">
                          <Phone className="h-5 w-5 text-primary mr-3" />
                          <p>{location.phone}</p>
                        </div>
                        
                        <div className="flex items-center">
                          <Mail className="h-5 w-5 text-primary mr-3" />
                          <p>{location.email}</p>
                        </div>
                        
                        <div className="flex items-start">
                          <Clock className="h-5 w-5 text-primary mr-3 mt-0.5" />
                          <p>{location.hours}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
            
            <div>
              <h2 className="text-2xl font-semibold mb-6">Send Us a Message</h2>
              
              {isSubmitted ? (
                <Card>
                  <CardHeader>
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                      <Check className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-center">Message Sent</CardTitle>
                    <CardDescription className="text-center">
                      Thank you for contacting Ainak Optical Store
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="mb-6">
                      We've received your message and will get back to you as soon as possible.
                    </p>
                    <Button onClick={() => setIsSubmitted(false)}>Send Another Message</Button>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="p-6">
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your full name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="Enter your email" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your phone number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="message"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Message</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="How can we help you?" 
                                  className="min-h-[150px]" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={contactMutation.isPending}
                        >
                          {contactMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Sending...
                            </>
                          ) : (
                            "Send Message"
                          )}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              )}
              
              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-4">Connect With Us</h3>
                <div className="flex space-x-4">
                  <a href="#" className="bg-primary hover:bg-primary/80 text-white p-3 rounded-full transition">
                    <i className="fab fa-facebook-f"></i>
                  </a>
                  <a href="#" className="bg-primary hover:bg-primary/80 text-white p-3 rounded-full transition">
                    <i className="fab fa-instagram"></i>
                  </a>
                  <a href="#" className="bg-primary hover:bg-primary/80 text-white p-3 rounded-full transition">
                    <i className="fab fa-twitter"></i>
                  </a>
                  <a href="#" className="bg-primary hover:bg-primary/80 text-white p-3 rounded-full transition">
                    <i className="fab fa-pinterest"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-12">
            <h2 className="text-2xl font-semibold mb-6 text-center">Find Us</h2>
            <div className="aspect-video w-full rounded-lg overflow-hidden">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.3059445135!2d-74.25986548248684!3d40.69714941932609!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sin!4v1623671939916!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={true}
                loading="lazy"
                title="Ainak Optical Store Locations"
              ></iframe>
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-8 text-center">
            <h2 className="text-2xl font-semibold mb-4">Customer Support</h2>
            <p className="mb-6 text-muted-foreground">
              Our customer support team is available Monday through Friday, 9AM to 6PM.
            </p>
            <div className="inline-flex items-center justify-center">
              <Phone className="h-5 w-5 text-primary mr-2" />
              <span className="text-lg font-medium">+1 (800) AINAK-123</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
