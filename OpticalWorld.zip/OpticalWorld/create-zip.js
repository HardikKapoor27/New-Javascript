
// Script to create a zip file of the project
const fs = require('fs');
const archiver = require('archiver');

// Create output file stream
const output = fs.createWriteStream('./ainak-optical-website.zip');
const archive = archiver('zip', {
  zlib: { level: 9 } // Maximum compression level
});

// Listen for errors
output.on('close', function() {
  console.log('Archive created successfully!');
  console.log('Total bytes: ' + archive.pointer());
});

archive.on('error', function(err) {
  throw err;
});

// Pipe archive data to the output file
archive.pipe(output);

// Add directories with all their files
archive.directory('client/', 'client');
archive.directory('server/', 'server');
archive.directory('shared/', 'shared');

// Add individual files from the root directory
const rootFiles = [
  '.gitignore',
  'drizzle.config.ts',
  'package.json',
  'package-lock.json',
  'postcss.config.js',
  'tailwind.config.ts',
  'theme.json',
  'tsconfig.json',
  'vite.config.ts'
];

rootFiles.forEach(file => {
  if (fs.existsSync(file)) {
    archive.file(file, { name: file });
  }
});

// Finalize the archive
archive.finalize();
